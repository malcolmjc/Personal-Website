var inContacts = 0;
var contactsPos = 0;

//When a user clicks they are no longer within contacts page
document.onclick = function(c) {
	if (inContacts) {
	   document.getElementById("dropdown").style.display = "none";
	   inContacts = 0;
	}

	setTimeout(function() {
		document.getElementById("dropdown").style.display = "";
	}, 500);
}

document.onkeydown = function(e) {
    e = e || window.event;
    var charCode = e.keyCode || e.which;

    //User is zoomed in enough that arrow keys will scroll 
    //the page left->right allow them to do so without changing page
    if (window.visualViewport.pageLeft > 0.0) 
    	return;

    //User pressed left arrow and isn't zoomed in, navigate them to new page
    else if (charCode == 37) {
    	if (document.title === "My Interests") {
    		if (inContacts) {
        	    document.getElementById("dropdown").style.display = "";
        	    inContacts = 0;
    		}
    		
        	else
    		   window.open("projects.html","_self");
    	}

    	else if (document.title === "My Projects")
    		window.open("index.html", "_self");
    }

    //User pressed right arrow and isn't zoomed in, navigate them to new page
    else if(charCode == 39) {
    	if (document.title === "Malcolm Craney")
    		window.open("projects.html", "_self");

    	else if (document.title === "My Projects")
    		window.open("interests.html", "_self");

    	else if (document.title === "My Interests") {
    		document.getElementById("dropdown").style.display = "block";
    		if (!inContacts) {
    			inContacts = 1;
    			document.getElementById("email-link").style.backgroundColor = "#42bff4";
    		}
    	}
    }

    //Check if user is in "Contacts" tab, if so highlight the appropriate section
    else if (charCode == 40) {
    	if (inContacts) {

    		if (contactsPos == 0) {
    			contactsPos = 1;
    		    document.getElementById("email-link").style.backgroundColor = "snow";
    		    document.getElementById("github-link").style.backgroundColor = "#42bff4";
    	    }

    	    else if (contactsPos == 1) {
    			contactsPos = 2;
    		    document.getElementById("github-link").style.backgroundColor = "snow";
    		    document.getElementById("linkedin-link").style.backgroundColor = "#42bff4";
    	    }
    	}
    }

    //Check if user is in "Contacts" tab, if so highlight the appropriate section
    else if (charCode == 38) {
    	if (inContacts) {
    		if (contactsPos == 1) {
    			contactsPos = 0;
    		    document.getElementById("email-link").style.backgroundColor = "#42bff4";
    		    document.getElementById("github-link").style.backgroundColor = "snow";
    	    }

    	    else if (contactsPos == 2) {
    			contactsPos = 1;
    		    document.getElementById("github-link").style.backgroundColor = "#42bff4";
    		    document.getElementById("linkedin-link").style.backgroundColor = "snow";
    	    }
    	}
    }

    //User pressed enter, check if they're in "Contacts", if so open the appropriate link
    else if (charCode == 13) {
    	if (inContacts) {
    		if (contactsPos == 0)
    			window.open("mailto:mjcraney@calpoly.edu", "_self");

    		else if (contactsPos == 1)
    			window.open("https://github.com/malcolmjc");

    		else if (contactsPos == 2)
    			window.open("https://www.linkedin.com/in/malcolm-craney-4a5491119/");

    	}
    }
};